import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.File;

public class Application {
    private static Application instance;
    private Connection connection;
    private Data data;
    private ManageProductsMenu productMenu = new ManageProductsMenu();
    private MainMenu mainMenu = new MainMenu();
    private CheckoutMenu checkoutMenu = new CheckoutMenu();
    private ProductControl productControl;
    private CheckoutControl checkoutControl;

    public static Application getInstance() {
        if (instance == null) {
            instance = new Application();
        }

        return instance;
    }

    public Connection getConnection() {
        return this.connection;
    }

    public MainMenu getMainMenu() {
        return this.mainMenu;
    }

    public ManageProductsMenu getManageProductsMenu() {
        return this.productMenu;
    }

    public ProductControl getProductControl() {
        return this.productControl;
    }

    public CheckoutMenu getCheckoutMenu() {
        return this.checkoutMenu;
    }

    public CheckoutControl getCheckoutControl() {
        return this.checkoutControl;
    }

    public Data getData() {
        return this.data;
    }

    private void initializeDatabase(Statement stmt) throws SQLException {
        System.out.println("Initializing new database: store.db");

        stmt.execute("create table Products (Name char(30), ProductID int PRIMARY KEY, Quantity double, " +
                "Price double, ProvName char(400), ProvNum int)");
        stmt.execute("create table Orders (OrderID int PRIMARY KEY, OrderDate DATETIME, CustName char(100), " +
                "Total double, Payment char(100), ItemsBought char(4000))");
        stmt.execute("INSERT INTO Orders (OrderID, OrderDate, CustName, Total, Payment, ItemsBought) " +
                "VALUES ('1000', '2017-09-21 08:53:00', 'Jim Jones', '13.21', 'Credit Card', '1 hammer'), " +
                "('1001', '2017-09-21 10:12:00', 'Sally Smith', '16.78', 'Cash', '3 potatoes,1 hammer'), " +
                "('1002', '2017-09-21 10:34:00', 'Bob Baker', '28.43', 'Credit Card', '1 pillow, 2 mugs'), " +
                "('1003', '2017-09-21 11:44:00', 'Chris Cooper', '14.44', 'Debit Card', '4 cacti'), " +
                "('1004', '2017-09-21 12:02:00', 'Tom Thumb', '601.22', 'Check', '36 pillows')");
        stmt.execute("INSERT INTO Products (Name, ProductID, Quantity, Price, ProvName, ProvNum) " +
                "VALUES ('Hammer', '1000', '10', '10.00', 'Bobs Hardware', '5553421'), " +
                "('Potato', '1001', '100', '0.79', 'Franks Farm', '5559522'), " +
                "('Cactus', '1002', '10', '3.50', 'Rio Grande Valley', '5557134'), " +
                "('Mug', '1003', '1000', '5.00', 'Martha Stewart', '5556112'), " +
                "('Pillow', '1004', '50', '15', 'Matress Firm', '5550918')");
    }

    private Application() {
        try {
            File dbFile = new File("store.db");
            boolean dbExists = dbFile.exists();

            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:store.db");
            Statement stmt = this.connection.createStatement();
            if (!dbExists) { initializeDatabase(stmt);
            } else { System.out.println("store.db found, skipping initialization."); }
        } catch (ClassNotFoundException var2) {
            System.out.println("SQLite is not installed. System exits with error!");
            System.exit(1);
        } catch (SQLException var3) {
            System.out.println("SQLite database is not ready. System exits with error!");
            System.exit(2);
        }

        this.data = new Data(this.connection);
        this.productMenu = new ManageProductsMenu();
        this.productControl = new ProductControl(this.productMenu, this.data);
        this.mainMenu = new MainMenu();

        this.data = new Data(this.connection);
        this.checkoutMenu = new CheckoutMenu();
        this.checkoutControl = new CheckoutControl(this.checkoutMenu, this.data);
        this.mainMenu = new MainMenu();
    }

    public static void main(String[] args) {
        getInstance().getMainMenu().setVisible(true);
    }
}