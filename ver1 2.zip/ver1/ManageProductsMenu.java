import java.awt.Dimension;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ManageProductsMenu extends JFrame {
    private JTextField productID = new JTextField();
    private JTextField productName = new JTextField();
    private JTextField quantity = new JTextField();
    private JTextField price = new JTextField();
    private JTextField providerName = new JTextField();
    private JTextField providerNum = new JTextField();
    private JButton loadButton = new JButton("Load Product");
    private JButton saveButton = new JButton("Save Product");

    public ManageProductsMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        JLabel title = new JLabel("Mr. Smith's Products");
        title.setHorizontalAlignment(0);
        this.getContentPane().add(title);
        this.setSize(500, 600);
        JPanel productIDPanel = new JPanel();
        JLabel idLabel = new JLabel("Product ID: ");
        productIDPanel.add(idLabel);
        productIDPanel.add(this.productID);
        this.productID.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(productIDPanel);
        JPanel productNamePanel = new JPanel();
        JLabel pName = new JLabel("Product Name: ");
        productNamePanel.add(pName);
        productNamePanel.add(this.productName);
        this.productName.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(productNamePanel);
        JPanel quantityPanel = new JPanel();
        JLabel quanLabel = new JLabel("Quantity: ");
        quantityPanel.add(quanLabel);
        quantityPanel.add(this.quantity);
        this.quantity.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(quantityPanel);
        JPanel pricePanel = new JPanel();
        JLabel priceLabel = new JLabel("Price: ");
        pricePanel.add(priceLabel);
        pricePanel.add(this.price);
        this.price.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(pricePanel);
        JPanel providerNamePanel = new JPanel();
        JLabel provNameLabel = new JLabel("Provider: ");
        providerNamePanel.add(provNameLabel);
        providerNamePanel.add(this.providerName);
        this.providerName.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(providerNamePanel);
        JPanel providerNumPanel = new JPanel();
        JLabel provNumLabel = new JLabel("Provider Phone: ");
        providerNumPanel.add(provNumLabel);
        providerNumPanel.add(this.providerNum);
        this.providerNum.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(providerNumPanel);
        JPanel panelButtons = new JPanel();
        panelButtons.add(this.loadButton);
        panelButtons.add(this.saveButton);
        this.getContentPane().add(panelButtons);
    }

    public JButton getLoadButton() {
        return this.loadButton;
    }

    public JButton getSaveButton() {
        return this.saveButton;
    }

    public JTextField getProductID() {
        return this.productID;
    }

    public JTextField getProductName() {
        return this.productName;
    }

    public JTextField getPrice() {
        return this.price;
    }

    public JTextField getQuantity() {
        return this.quantity;
    }

    public JTextField getProviderName() {
        return this.providerName;
    }

    public JTextField getProviderNum() {
        return this.providerNum;
    }
}
