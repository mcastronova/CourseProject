import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.Date;
import java.util.Random;



public class CheckoutControl implements ActionListener {
    private CheckoutMenu menu;
    private Data data;
    private Order order = null;

    public CheckoutControl(CheckoutMenu menu, Data data) {
        this.data = data;
        this.menu = menu;
        menu.getAddProductButton().addActionListener(this);
        menu.getFinishButton().addActionListener(this);
        order = new Order();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menu.getAddProductButton()) {
            //System.out.println("You pressed the add button.");
            addProduct();
        } else if (e.getSource() == menu.getFinishButton()) {
            //System.out.println("You pressed the finish button.");
            saveOrder();
        }
    }

    private void saveOrder() {
        Order order = new Order();
        String customerName = JOptionPane.showInputDialog("Enter Customer's Name: ");
        order.setCustomerName(customerName);
        if (customerName.length() == 0) {
            JOptionPane.showMessageDialog((Component)null, "Invalid name! Please provide a non-empty customer name!");
        }
        String typePay = JOptionPane.showInputDialog("Enter payment type (cash, credit, debit, check): ");
        order.setTypePay(typePay);
        if (typePay.length() == 0) {
            JOptionPane.showMessageDialog((Component)null, "Invalid payment type! Please provide a non-empty payment type!");
        }

        Random rand = new Random();
        order.setOrderID(rand.nextInt((1) + 1) + 1);

        Date date = new Date(3, 20, 2017);
        order.setDate(date);
        order.setTotalCost(100);
        order.setItemsBought("hammer");
        this.data.saveOrder(order);
    }

    private void addProduct() {
        String productID = JOptionPane.showInputDialog("Enter ProductID: ");
        Product product = this.data.loadProduct(Integer.parseInt(productID));
        if (product == null) {
            JOptionPane.showMessageDialog((Component)null, "This product does not exist!");
            return;
        } else {
            double quantity = Double.parseDouble(JOptionPane.showInputDialog((Component)null, "Enter quantity: "));
            if (quantity < 0.0D) {
                JOptionPane.showMessageDialog((Component)null, "This quantity is not valid!");
            } else if (quantity > product.getQuantity()) {
                JOptionPane.showMessageDialog((Component)null, "There aren't enough in stock!");
            } else {
                OrderLine line = new OrderLine();
                line.setOrderID(this.order.getOrderID());
                //System.out.println("I set the orderID.");
                line.setProductID(product.getProductID());
                //System.out.println("I set the productID.");
                line.setQuantity(quantity);
                //System.out.println("I set the quantity.");
                line.setCost(quantity * product.getPrice());
                //System.out.println("I set the cost.");
                product.setQuantity(product.getQuantity() - quantity);
                //System.out.println("I updated the qantity.");
                this.data.saveProduct(product);
                this.order.getLines().add(line);
                this.order.setTotalCost(this.order.getTotalCost() + line.getCost());
                Object[] row = new Object[]{line.getProductID(), product.getProductName(), product.getPrice(), line.getQuantity(), line.getCost()};
                this.menu.addRow(row);
                this.menu.getTotalLabel().setText("Total: " + this.order.getTotalCost());
                this.menu.invalidate();
            }
        }
    }
}
