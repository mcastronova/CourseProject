import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ProductControl implements ActionListener {
    private ManageProductsMenu productMenu;
    private Data data;

    public ProductControl(ManageProductsMenu productMenu, Data data) {
        this.data = data;
        this.productMenu = productMenu;
        productMenu.getLoadButton().addActionListener(this);
        productMenu.getSaveButton().addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.productMenu.getLoadButton()) {
            this.loadProduct();
        } else if (e.getSource() == this.productMenu.getSaveButton()) {
            this.saveProduct();
        }

    }

    private void loadProduct() {
        boolean var1 = false;

        int productID;
        try {
            productID = Integer.parseInt(this.productMenu.getProductID().getText());
        } catch (NumberFormatException var3) {
            JOptionPane.showMessageDialog((Component)null, "Product ID does not exist! Please provide a valid product ID!");
            return;
        }

        Product product = this.data.loadProduct(productID);
        if (product == null) {
            JOptionPane.showMessageDialog((Component)null, "This product ID does not exist in the database.");
        } else {
            this.productMenu.getProductName().setText(product.getProductName());
            this.productMenu.getPrice().setText(String.valueOf(product.getPrice()));
            this.productMenu.getQuantity().setText(String.valueOf(product.getQuantity()));
            this.productMenu.getProviderName().setText(String.valueOf(product.getProviderName()));
            this.productMenu.getProviderNum().setText(String.valueOf(product.getProviderNum()));
        }
    }

    private void saveProduct() {
        int productID;
        try {
            productID = Integer.parseInt(this.productMenu.getProductID().getText());
            //System.out.println("I set the product ID");
        } catch (NumberFormatException var13) {
            JOptionPane.showMessageDialog((Component)null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }

        int providerNum;
        try {
            providerNum = Integer.parseInt(this.productMenu.getProviderNum().getText());
            //System.out.println("I set the provider num");
        } catch (NumberFormatException var12) {
            JOptionPane.showMessageDialog((Component)null, "Invalid provider phone number! Please provide a valid provider phone number!");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(this.productMenu.getPrice().getText());
            //System.out.println("I set the price");
        } catch (NumberFormatException var11) {
            JOptionPane.showMessageDialog((Component)null, "Invalid product price! Please provide a valid product price!");
            return;
        }

        double productQuantity;
        try {
            productQuantity = Double.parseDouble(this.productMenu.getQuantity().getText());
            //System.out.println("I set the quantity");
        } catch (NumberFormatException var10) {
            JOptionPane.showMessageDialog((Component)null, "Invalid product quantity! Please provide a valid product quantity!");
            return;
        }

        String productName = this.productMenu.getProductName().getText().trim();
        if (productName.length() == 0) {
            JOptionPane.showMessageDialog((Component)null, "Invalid product name! Please provide a non-empty product name!");
        } else {
            String provName = this.productMenu.getProviderName().getText().trim();
            //System.out.println("I set the provider name");
            if (provName.length() == 0) {
                JOptionPane.showMessageDialog((Component)null, "Invalid provider name! Please provide a non-empty provider name!");
            } else {
                Product product = new Product();
                product.setProductID(productID);
                product.setProductName(productName);
                product.setPrice(price);
                product.setQuantity(productQuantity);
                product.setProviderName(provName);
                product.setProviderNum(providerNum);
                this.data.saveProduct(product);
            }
        }
    }
}
