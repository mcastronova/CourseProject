import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.*;

public class Data {
    private Connection connection;

    public Data(Connection connection) {
        this.connection = connection;
    }

    public Product loadProduct(int productID) {
        try {
            String query = "SELECT * FROM Products WHERE ProductID = " + productID;
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Product product = new Product();
                product.setProductID(resultSet.getInt(2));
                product.setProductName(resultSet.getString(1));
                product.setPrice(resultSet.getDouble(4));
                product.setQuantity(resultSet.getDouble(3));
                product.setProviderName(resultSet.getString(5));
                product.setProviderNum(resultSet.getInt(6));
                resultSet.close();
                statement.close();
                return product;
            }
        } catch (SQLException var6) {
            System.out.println("Database access error!");
            var6.printStackTrace();
        }

        return null;
    }

    public void saveProduct(Product product) {
        try {
            PreparedStatement statement = this.connection.prepareStatement("SELECT * FROM Products WHERE ProductID = ?");
            statement.setInt(1, product.getProductID());

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                statement = this.connection.prepareStatement("UPDATE Products SET Name = ?, Price = ?, Quantity = ?, ProvName = ?, ProvNum = ? WHERE ProductID = ?");
                statement.setString(1, product.getProductName());
                statement.setDouble(2, product.getPrice());
                statement.setDouble(3, product.getQuantity());
                statement.setString(4, product.getProviderName());
                statement.setInt(5, product.getProviderNum());
                statement.setInt(6, product.getProductID());
            } else {
                statement = this.connection.prepareStatement("INSERT INTO Products VALUES (?, ?, ?, ?, ?, ?)");
                statement.setString(1, product.getProductName());
                statement.setDouble(4, product.getPrice());
                statement.setDouble(3, product.getQuantity());
                statement.setString(5, product.getProviderName());
                statement.setInt(6, product.getProviderNum());
                statement.setInt(2, product.getProductID());
            }

            statement.execute();
            resultSet.close();
            statement.close();
        } catch (SQLException var4) {
            System.out.println("Database access error!");
            var4.printStackTrace();
        }

    }

    public boolean saveOrder(Order order) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)");
            statement.setInt(1, order.getOrderID());
            statement.setDate(2, order.getDate());
            statement.setString(3, order.getCustomerName());
            statement.setDouble(4, order.getTotalCost());
            statement.setString(5, order.getTypePay());
            statement.setString(6, order.getItemsBought());

            statement.execute();    // commit to the database;
            statement.close();

            statement = connection.prepareStatement("INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)");
            for (OrderLine line: order.getLines()) { // store for each order line!
                statement.setInt(1, line.getOrderID());
                statement.setInt(2, line.getProductID());
                statement.setDouble(3, line.getQuantity());
                statement.setDouble(4, line.getCost());
                statement.setString(5, order.getTypePay());
                statement.setString(6, order.getItemsBought());

                statement.execute();    // commit to the database;
            }
            statement.close();
            return true; // save successfully!
        }
        catch (SQLException e) {
            System.out.println("Database access error!");
            e.printStackTrace();
            return false;
        }
    }
}
