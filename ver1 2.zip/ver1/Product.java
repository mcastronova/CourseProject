public class Product {
    private int productID;
    private String productName;
    private double price;
    private double quantity;
    private String providerName;
    private int providerNum;

    public Product() {
    }

    public int getProductID() {
        return this.productID;
    }

    public void setProductID(int ID) {
        this.productID = ID;
    }

    public String getProductName() {
        return this.productName;
    }

    public void setProductName(String name) {
        this.productName = name;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getQuantity() {
        return this.quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getProviderName() {
        return this.providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public int getProviderNum() {
        return this.providerNum;
    }

    public void setProviderNum(int providerNum) {
        this.providerNum = providerNum;
    }
}
