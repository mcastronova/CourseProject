import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderID;
    private String customerName;
    private double totalCost;
    private String typePay;
    private Date date;
    private String itemsBought;
    private List<OrderLine> lines = new ArrayList();

    public Order() {
    }

    public int getOrderID() {
        return this.orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public String getCustomerName() {
        return this.customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public double getTotalCost() {
        return this.totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public String getTypePay() {
        return this.typePay;
    }

    public void setTypePay(String typePay) {
        this.typePay = typePay;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getItemsBought() {
        return this.itemsBought;
    }

    public void setItemsBought(String itemsBought) {
        this.itemsBought = itemsBought;
    }

    public void addLine(OrderLine line) {
        this.lines.add(line);
    }

    public void removeLine(OrderLine line) {
        this.lines.remove(line);
    }

    public List<OrderLine> getLines() {
        return this.lines;
    }
}
