import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ReportMenu extends JFrame {
    private JButton generateButton = new JButton("Generate Report");
    private DefaultTableModel items = new DefaultTableModel();
    private JTable reportTable;

    public ReportMenu() {
        this.reportTable = new JTable(this.items);
        this.setLayout(new BoxLayout(this.getContentPane(), 1));
        JLabel title = new JLabel("Business Report");
        this.getContentPane().add(title);
        this.setSize(600, 300);
        this.items.addColumn("Product ID");
        this.items.addColumn("Product Name");
        this.items.addColumn("Units Sold");
        this.items.addColumn("Total $ Paid");
        JPanel reportPanel = new JPanel();
        reportPanel.setLayout(new BoxLayout(reportPanel, 3));
        reportPanel.add(this.reportTable.getTableHeader());
        reportPanel.add(this.reportTable);
        this.reportTable.setFillsViewportHeight(true);
        this.getContentPane().add(reportPanel);

        JPanel panelButton = new JPanel();
        panelButton.setPreferredSize(new Dimension(400, 100));
        panelButton.add(generateButton);
        this.getContentPane().add(panelButton);
    }

    public JButton getGenerateButton() {
        return this.generateButton;
    }

    public void addRow(Object[] row) {
        this.items.addRow(row);
        this.items.fireTableDataChanged();
    }

}
