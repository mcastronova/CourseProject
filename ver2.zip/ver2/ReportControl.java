import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.ArrayList;

public class ReportControl implements ActionListener {
    private ReportMenu reportMenu;
    private Data data;

    public ReportControl(ReportMenu reportMenu, Data data) {
        this.data = data;
        this.reportMenu = reportMenu;
        //System.out.println("I made it in the constructor for report control.");
        reportMenu.getGenerateButton().addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == reportMenu.getGenerateButton()) {
            //System.out.println("You pressed the add button.");
            generateReport();
        }
    }

    private void generateReport() {
        System.out.println("Generating report...");

        //load any products we find in the database into a product array
        ArrayList<Product> holder = new ArrayList<Product>();
        for (int i = 0; i < 50000; i++) {
            //System.out.println("Now checking " + i);
            if (data.loadProduct(i) != null) {
                holder.add(data.loadProduct(i));
            }
        }

        for (int i = 0; i < holder.size(); i++) {
             //System.out.println("Now adding: " + i);
             Product product = holder.get(i);
             Object[] row = new Object[]{product.getProductID(), product.getProductName(), product.getAmountSold(), product.getPrice() * product.getAmountSold()};
             this.reportMenu.addRow(row);
        }

        System.out.println("Report generated.");
    }

}
