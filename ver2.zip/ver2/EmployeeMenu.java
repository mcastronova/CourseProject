import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;
import javax.swing.*;

public class EmployeeMenu extends JFrame {
    private JTextField username = new JTextField();
    private JTextField password = new JTextField();
    private JTextField empName = new JTextField();
    private JTextField role = new JTextField();
    private JTextField wage = new JTextField();
    private JFileChooser photo = new JFileChooser();
    private JButton loadButton = new JButton("Load Employee");
    private JButton saveButton = new JButton("Save Employee");

    public EmployeeMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        JLabel title = new JLabel("Mr. Smith's Employees");
        title.setHorizontalAlignment(0);
        this.getContentPane().add(title);
        this.setSize(500, 600);

        JPanel usernamePanel = new JPanel();
        JLabel usernameLabel = new JLabel("Username: ");
        usernamePanel.add(usernameLabel);
        usernamePanel.add(this.username);
        this.username.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(usernamePanel);

        JPanel passwordPanel = new JPanel();
        JLabel passwordLabel = new JLabel("Password: ");
        passwordPanel.add(passwordLabel);
        passwordPanel.add(this.password);
        this.password.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(passwordPanel);

        JPanel namePanel = new JPanel();
        JLabel nameLabel = new JLabel("Name: ");
        namePanel.add(nameLabel);
        namePanel.add(this.empName);
        this.empName.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(namePanel);

        JPanel rolePanel = new JPanel();
        JLabel roleLabel = new JLabel("Role: ");
        rolePanel.add(roleLabel);
        rolePanel.add(this.role);
        this.role.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(rolePanel);

        JPanel wagePanel = new JPanel();
        JLabel wageLabel = new JLabel("Wage: ");
        wagePanel.add(wageLabel);
        wagePanel.add(this.wage);
        this.wage.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(wagePanel);

        JPanel photoPanel = new JPanel();
        JLabel photoLabel = new JLabel("Photo: ");
        photoPanel.add(photoLabel);
        photoPanel.add(this.photo);
        this.getContentPane().add(photoPanel);

        JPanel panelButtons = new JPanel();
        panelButtons.add(this.loadButton);
        panelButtons.add(this.saveButton);
        this.getContentPane().add(panelButtons);
    }

    public JButton getLoadButton() {
        return this.loadButton;
    }

    public JButton getSaveButton() {
        return this.saveButton;
    }

    public JTextField getUsername() {
        return username;
    }

    public JTextField getPassword() {
        return password;
    }

    public JFileChooser getPhoto() {
        return photo;
    }

    public JTextField getEmpName() {
        return empName;
    }

    public JTextField getRole() {
        return role;
    }

    public JTextField getWage() {
        return wage;
    }
}
