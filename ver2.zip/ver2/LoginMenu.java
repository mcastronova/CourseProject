import javax.swing.*;
import java.awt.*;


public class LoginMenu extends JFrame{
    private JButton loginButton = new JButton("Login");
    private JButton cancelButton = new JButton("Exit");
    private JTextField username = new JTextField();
    private JTextField password = new JTextField();

    public LoginMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        this.setSize(400, 300);
        this.setDefaultCloseOperation(3);

        JLabel title = new JLabel("Mr. Smith's Grocery Store");
        JPanel panelTitle = new JPanel();
        panelTitle.add(title);

        JPanel panelButtons = new JPanel();
        this.loginButton.setPreferredSize(new Dimension(120, 40));
        this.cancelButton.setPreferredSize(new Dimension(120, 40));
        panelButtons.add(this.loginButton);
        panelButtons.add(this.cancelButton);

        JPanel panelUsername = new JPanel();
        JLabel usernameTitle = new JLabel("Username: ");
        this.username.setPreferredSize(new Dimension(200, 30));
        panelUsername.add(usernameTitle);
        panelUsername.add(username);

        JPanel panelPassword = new JPanel();
        JLabel passwordTitle = new JLabel("Password: ");
        this.password.setPreferredSize(new Dimension(200, 30));
        panelPassword.add(passwordTitle);
        panelPassword.add(password);

        this.getContentPane().add(panelTitle);
        this.getContentPane().add(panelUsername);
        this.getContentPane().add(panelPassword);
        this.getContentPane().add(panelButtons);
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public JButton getLoginButton() {
        return loginButton;
    }

    public JTextField getPassword() {
        return password;
    }

    public JTextField getUsername() {
        return username;
    }
}
