import javax.swing.*;
import java.awt.*;


public class ProfileMenu extends JFrame {
    private JButton updatePasswordButton = new JButton("Update Password");
    private JButton updatePhotoButton = new JButton("Update Photo");
    private Employee employee;

    public ProfileMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        this.setSize(400, 300);
        JLabel title = new JLabel("Mr. Smith's Grocery Store");
        JPanel panelTitle = new JPanel();
        panelTitle.add(title);
        this.getContentPane().add(panelTitle);

        JPanel panelPhoto = new JPanel();
        this.getContentPane().add(panelPhoto);

        //JPanel panelName = new JPanel();
        //JLabel nameLabel = new JLabel("Name: ");
        //JLabel name;
        //if (employee == null ) {
        //    name =  new JLabel("null");
        //} else {
        //    name =  new JLabel(employee.getName());
        //}
       // panelName.add(nameLabel);
       // panelName.add(name);
        //this.getContentPane().add(panelName);

        //JPanel panelUsername = new JPanel();
        //JLabel usernameLabel = new JLabel("Username: ");
        //JLabel username =  new JLabel(employee.getUsername());
        //up
        //panelUsername.add(usernameLabel);
        //panelUsername.add(username);
        //up
        //this.getContentPane().add(panelUsername);

        //JPanel panelPassword = new JPanel();
        //JLabel passwordLabel = new JLabel("Password: ");
        //JLabel password =  new JLabel(employee.getPassword());
        //panelPassword.add(passwordLabel);
       // panelPassword.add(password);
        //this.getContentPane().add(panelPassword);

        //JPanel panelRole = new JPanel();
        //JLabel roleLabel = new JLabel("Role: ");
        ////JLabel role =  new JLabel(employee.getRole());
        //panelRole.add(roleLabel);
        //panelRole.add(role);
        //this.getContentPane().add(panelRole);

        //JPanel panelWage = new JPanel();
        //JLabel wageLabel = new JLabel("Wage: $");
        //JLabel wageLabel = new JLabel("Wage: $" + employee.getWage());
        //JLabel wage = new JLabel(Double.toString(employee.getWage()));
        //panelWage.add(wageLabel);
       // panelWage.add(wage);
        //this.getContentPane().add(panelWage);

        JPanel panelButtons = new JPanel();
        this.updatePasswordButton.setPreferredSize(new Dimension(120, 40));
        this.updatePhotoButton.setPreferredSize(new Dimension(120, 40));
        panelButtons.add(this.updatePasswordButton);
        panelButtons.add(this.updatePhotoButton);
        this.getContentPane().add(panelButtons);
    }

    public JButton getUpdatePasswordButton() {
        return updatePasswordButton;
    }

    public JButton getUpdatePhotoButton() {
        return updatePhotoButton;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
}