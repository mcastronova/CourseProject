import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.*;

public class Data {
    private Connection connection;
    private String currentUsername;

    public Data(Connection connection) {
        this.connection = connection;
    }

    public Product loadProduct(int productID) {
        try {
            String query = "SELECT * FROM Products WHERE ProductID = " + productID;
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Product product = new Product();
                product.setProductID(resultSet.getInt(2));
                product.setProductName(resultSet.getString(1));
                product.setPrice(resultSet.getDouble(4));
                product.setQuantity(resultSet.getDouble(3));
                product.setProviderName(resultSet.getString(5));
                product.setProviderNum(resultSet.getInt(6));
                product.setAmountSold(resultSet.getDouble(7));
                resultSet.close();
                statement.close();
                return product;
            }
        } catch (SQLException var6) {
            System.out.println("Database access error! see loadProduct()");
            var6.printStackTrace();
        }

        return null;
    }

    public void saveProduct(Product product) {
        try {
            PreparedStatement statement = this.connection.prepareStatement("SELECT * FROM Products WHERE ProductID = ?");
            statement.setInt(1, product.getProductID());

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                statement = this.connection.prepareStatement("UPDATE Products SET Name = ?, Price = ?, Quantity = ?, ProvName = ?, ProvNum = ?, NumSold = ? WHERE ProductID = ?");
                statement.setString(1, product.getProductName());
                statement.setDouble(2, product.getPrice());
                statement.setDouble(3, product.getQuantity());
                statement.setString(4, product.getProviderName());
                statement.setInt(5, product.getProviderNum());
                statement.setInt(6, product.getProductID());
                statement.setDouble(7, product.getAmountSold());
            } else {
                statement = this.connection.prepareStatement("INSERT INTO Products VALUES (?, ?, ?, ?, ?, ?, ?)");
                statement.setString(1, product.getProductName());
                statement.setDouble(4, product.getPrice());
                statement.setDouble(3, product.getQuantity());
                statement.setString(5, product.getProviderName());
                statement.setInt(6, product.getProviderNum());
                statement.setInt(2, product.getProductID());
                statement.setDouble(7, product.getAmountSold());
            }

            statement.execute();
            resultSet.close();
            statement.close();
        } catch (SQLException var4) {
            System.out.println("Database access error! see saveProduct()");
            var4.printStackTrace();
        }

    }

    public void saveOrder(Order order) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)");
            statement.setInt(1, order.getOrderID());
            statement.setDate(2, order.getDate());
            statement.setString(3, order.getCustomerName());
            statement.setDouble(4, order.getTotalCost());
            statement.setString(5, order.getTypePay());
            statement.setString(6, order.getItemsBought());

            statement.execute();    // commit to the database;
            statement.close();

            statement = connection.prepareStatement("INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)");
            for (OrderLine line: order.getLines()) { // store for each order line!
                statement.setInt(1, line.getOrderID());
                statement.setInt(2, line.getProductID());
                statement.setDouble(3, line.getQuantity());
                statement.setDouble(4, line.getCost());
                statement.setString(5, order.getTypePay());
                statement.setString(6, order.getItemsBought());

                statement.execute();    // commit to the database;
            }
            statement.close();
            //return true; // save successfully!
        }
        catch (SQLException e) {
            System.out.println("Database access error! see saveOrder()");
            e.printStackTrace();
            //return false;
        }
    }


    public String checkEmployee(String username, String password) {
        try {
            String query = "SELECT * FROM Employees WHERE Username = '" + username + "'";
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Employee employee = new Employee();
                employee.setUsername(resultSet.getString(1));
                employee.setPassword(resultSet.getString(2));
                employee.setName(resultSet.getString(3));
                employee.setRole(resultSet.getString(4));
                employee.setWage(resultSet.getDouble(5));
                resultSet.close();
                statement.close();
                if (employee.getPassword().equals(password)){
                    return employee.getRole();
                } else {
                    return null;
                }
            }
        } catch (SQLException var6) {
            System.out.println("Database access error! see checkEmployee()");
            var6.printStackTrace();
        }
        return null;
    }


    public void setCurrentUsername(String username) {
        currentUsername = username;
    }


    public Employee getCurrentEmployee() {
        try {
            String query = "SELECT * FROM Employees WHERE Username = '" + currentUsername + "'";
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Employee employee = new Employee();
                System.out.println(employee.getUsername());
                System.out.println(currentUsername);
                employee.setUsername(resultSet.getString(1));
                employee.setPassword(resultSet.getString(2));
                employee.setName(resultSet.getString(3));
                employee.setRole(resultSet.getString(4));
                employee.setWage(resultSet.getDouble(5));
                employee.setPhoto(resultSet.getString(6));
                resultSet.close();
                statement.close();
                return employee;
            }
        } catch (SQLException var6) {
            System.out.println("Database access error! see getCurrentEmployee()");
            var6.printStackTrace();
        }
        return null;
    }

    public void changePassword(String old, String newPWord) {
        try {
            String query = "SELECT * FROM Employees WHERE Username = '" + currentUsername + "'";
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Employee employee = new Employee();
                employee.setUsername(resultSet.getString(1));
                employee.setPassword(resultSet.getString(2));
                resultSet.close();
                statement.close();

                if (old.equalsIgnoreCase(employee.getPassword())) {
                    this.connection.prepareStatement("UPDATE Employees SET Password = '" + newPWord + "' WHERE Username = '" + currentUsername + "'");
                }
            }
        } catch (SQLException var6) {
            System.out.println("Database access error! see changePassword()");
            var6.printStackTrace();
        }
    }

    public Employee loadEmployee(String username) {
        try {
            String query = "SELECT * FROM Employees WHERE Username = '" + username + "'";
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                Employee employee = new Employee();
                employee.setUsername(resultSet.getString(1));
                employee.setPassword(resultSet.getString(2));
                employee.setName(resultSet.getString(3));
                employee.setRole(resultSet.getString(4));
                employee.setWage(resultSet.getDouble(5));
                employee.setPhoto(resultSet.getString(6));
                resultSet.close();
                statement.close();
                return employee;
            }
        } catch (SQLException var6) {
            System.out.println("Database access error! see loadEmployee()");
            var6.printStackTrace();
        }

        return null;
    }

    public void saveEmployee(Employee employee) {
        try {
            PreparedStatement statement = this.connection.prepareStatement("SELECT * FROM Employees WHERE Username = '" + employee.getUsername() + "'");

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                statement = this.connection.prepareStatement("UPDATE Employees SET Password = ?, Name = ?, Role = ?, Wage = ?, Photo = ? WHERE Username = ?");
                statement.setString(6, employee.getUsername());
                statement.setString(1, employee.getPassword());
                statement.setString(2, employee.getName());
                statement.setString(3, employee.getRole());
                statement.setDouble(4, employee.getWage());
                statement.setString(5, employee.getPhoto());
            } else {
                statement = this.connection.prepareStatement("INSERT INTO Employees VALUES (?, ?, ?, ?, ?, ?)");
                statement.setString(1, employee.getUsername());
                statement.setString(2, employee.getPassword());
                statement.setString(3, employee.getName());
                statement.setString(4, employee.getRole());
                statement.setDouble(5, employee.getWage());
                statement.setString(6, employee.getPhoto());
            }

            statement.execute();
            resultSet.close();
            statement.close();
        } catch (SQLException var4) {
            System.out.println("Database access error! see saveEmployee()");
            var4.printStackTrace();
        }

    }
}
