import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginControl implements ActionListener {
    private LoginMenu loginMenu;
    private ProfileControl profileControl;
    private Data data;

    public LoginControl(LoginMenu loginMenu, Data data) {
        this.data = data;
        this.loginMenu = loginMenu;
        //System.out.println("I made it in the constructor for login control");
        loginMenu.getCancelButton().addActionListener(this);
        loginMenu.getLoginButton().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.loginMenu.getLoginButton()) {
            //System.out.println("I made it in the action listener for the login button");
            this.checkEmployee();
        } else if (e.getSource() == this.loginMenu.getCancelButton()) {
            //System.out.println("I made it in the action listener for the cancel button");
            System.exit(0);
        }

    }

    private void checkEmployee() {
        String username = this.loginMenu.getUsername().getText();
        String password = this.loginMenu.getPassword().getText();
        this.data.setCurrentUsername(username);

        String role = this.data.checkEmployee(username, password);
        if (role == null) {
            JOptionPane.showMessageDialog((Component)null, "This user does not exist in the database.");
        } else if (role.equalsIgnoreCase("cashier")) {
            Application.getInstance().getMainCashierMenu().setVisible(true);
        } else if (role.equalsIgnoreCase("manager")) {
            Application.getInstance().getMainManagerMenu().setVisible(true);
        }
    }

}
