import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class EmployeeControl implements ActionListener {
    private EmployeeMenu employeeMenu;
    private Data data;

    public EmployeeControl(EmployeeMenu employeeMenu, Data data) {
        this.data = data;
        this.employeeMenu = employeeMenu;
        employeeMenu.getLoadButton().addActionListener(this);
        employeeMenu.getSaveButton().addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.employeeMenu.getLoadButton()) {
            this.loadEmployee();
        } else if (e.getSource() == this.employeeMenu.getSaveButton()) {
            this.saveEmployee();
        }

    }

    private void loadEmployee() {
        String username;
        try {
            username = this.employeeMenu.getUsername().getText();
        } catch (NumberFormatException var3) {
            JOptionPane.showMessageDialog((Component)null, "Employee does not exist! Please provide a valid employee!");
            return;
        }

        Employee employee = this.data.loadEmployee(username);
        if (employee == null) {
            JOptionPane.showMessageDialog((Component)null, "This employee does not exist in the database.");
        } else {
            this.employeeMenu.getUsername().setText(employee.getUsername());
            this.employeeMenu.getPassword().setText(String.valueOf(employee.getPassword()));
            this.employeeMenu.getEmpName().setText(String.valueOf(employee.getName()));
            this.employeeMenu.getRole().setText(String.valueOf(employee.getRole()));
            this.employeeMenu.getWage().setText(String.valueOf(employee.getWage()));
            //this.employeeMenu.getPhoto().setText(String.valueOf(employee.getPhoto()));
        }
    }

    private void saveEmployee() {
        String username = this.employeeMenu.getUsername().getText().trim();

        String password = this.employeeMenu.getPassword().getText().trim();

        String name = this.employeeMenu.getEmpName().getText().trim();

        String role = this.employeeMenu.getRole().getText().trim();

        double wage;
        try {
            wage = Double.parseDouble(this.employeeMenu.getWage().getText());
            //System.out.println("I set the amount sold");
        } catch (NumberFormatException var9) {
            JOptionPane.showMessageDialog((Component)null, "Invalid wage! Please provide a valid wage!");
            return;
        }

        String photo = this.employeeMenu.getEmpName().getText().trim();
        if ((password.length() == 0) || (role.length() == 0) || (name.length() == 0) || (username.length() == 0)) {
            JOptionPane.showMessageDialog((Component)null, "Invalid employee info! Please provide non-empty values!");
        } else {
            Employee employee = new Employee();
            employee.setUsername(username);
            employee.setPassword(password);
            employee.setName(name);
            employee.setRole(role);
            employee.setWage(wage);
            employee.setPhoto(photo);
            this.data.saveEmployee(employee);
            }
        }
    }