import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainManagerMenu extends JFrame {
    private JButton checkOutButton = new JButton("Checkout");
    private JButton manageProductsButton = new JButton("Manage Products");
    private JButton manageProfileButton = new JButton("Manage Profile");
    private JButton manageEmployeesButton = new JButton("Manage Employees");
    private JButton printBusinessReportButton = new JButton("Print Business Report");


    public MainManagerMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        this.setSize(400, 300);
        this.setDefaultCloseOperation(3);
        JLabel title = new JLabel("Mr. Smith's Grocery Store");
        JPanel panelTitle = new JPanel();
        JPanel panelButtons = new JPanel();
        this.checkOutButton.setPreferredSize(new Dimension(120, 40));
        this.manageProductsButton.setPreferredSize(new Dimension(120, 40));
        panelTitle.add(title);
        panelButtons.add(this.checkOutButton);
        panelButtons.add(this.manageProductsButton);
        panelButtons.add(this.manageProfileButton);
        panelButtons.add(this.manageEmployeesButton);
        panelButtons.add(this.printBusinessReportButton);
        this.getContentPane().add(panelTitle);
        this.getContentPane().add(panelButtons);

        this.checkOutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getCheckoutMenu().setVisible(true);
            }
        });

        this.manageProductsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getManageProductsMenu().setVisible(true);
            }
        });

        this.manageProfileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProfileMenu().setVisible(true);
            }
        });

        this.manageEmployeesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getEmployeeMenu().setVisible(true);
            }
        });

        this.printBusinessReportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { Application.getInstance().getReportMenu().setVisible(true); }
        });
    }
}
