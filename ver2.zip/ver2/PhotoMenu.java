import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PhotoMenu extends JFrame {
    private JFileChooser photoChooser = new JFileChooser();
    private JButton applyButton = new JButton("Apply");
    private JButton cancelButton = new JButton("Cancel");

    public PhotoMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        JLabel title = new JLabel("Mr. Smith's Products");
        title.setHorizontalAlignment(0);
        this.getContentPane().add(title);
        this.setSize(500, 600);

        JPanel filePanel = new JPanel();
        JLabel fileLabel = new JLabel("Choose a new photo: ");
        filePanel.add(fileLabel);
        this.getContentPane().add(filePanel);

        JPanel choosePanel = new JPanel();
        choosePanel.add(photoChooser);
        this.getContentPane().add(choosePanel);

        JPanel panelButtons = new JPanel();
        panelButtons.add(this.applyButton);
        panelButtons.add(this.cancelButton);
        this.getContentPane().add(panelButtons);

        this.cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
    }

    //apply button goes to data and saves photo
}
