import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProfileControl implements ActionListener{
    private ProfileMenu profileMenu;
    private Data data;

    public ProfileControl(ProfileMenu profileMenu, Data data) {
        this.data = data;
        this.profileMenu = profileMenu;
        //System.out.println("I made it in the constructor for login control");
        profileMenu.getUpdatePasswordButton().addActionListener(this);
        profileMenu.getUpdatePhotoButton().addActionListener(this);
        getCurrentEmployee();
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.profileMenu.getUpdatePasswordButton()) {
            //System.out.println("I made it in the action listener for the login button");
            Application.getInstance().getPasswordMenu().setVisible(true);
        } else if (e.getSource() == this.profileMenu.getUpdatePhotoButton()) {
            //System.out.println("I made it in the action listener for the cancel button");
            Application.getInstance().getPhotoMenu().setVisible(true);
        }

    }

    public void getCurrentEmployee() {
        Employee employee = this.data.getCurrentEmployee();
        this.profileMenu.setEmployee(employee);
        //System.out.println("Employee: " + employee.getUsername());
    }

}
