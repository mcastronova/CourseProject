import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PasswordMenu extends JFrame {
    private JTextField oldPWord = new JTextField();
    private JTextField newPWord = new JTextField();
    private JTextField confirmPWord = new JTextField();
    private JButton applyButton = new JButton("Apply");
    private JButton cancelButton = new JButton("Cancel");

    public PasswordMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        JLabel title = new JLabel("Mr. Smith's Products");
        title.setHorizontalAlignment(0);
        this.getContentPane().add(title);
        this.setSize(500, 600);

        JPanel oldPanel = new JPanel();
        JLabel oldLabel = new JLabel("Old Password: ");
        oldPanel.add(oldLabel);
        oldPanel.add(this.oldPWord);
        this.oldPWord.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(oldPanel);

        JPanel newPanel = new JPanel();
        JLabel newLabel = new JLabel("New Password: ");
        newPanel.add(newLabel);
        newPanel.add(this.newPWord);
        this.newPWord.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(newPanel);

        JPanel confirmPanel = new JPanel();
        JLabel confirmLabel = new JLabel("Confirm New Password: ");
        confirmPanel.add(confirmLabel);
        confirmPanel.add(this.confirmPWord);
        this.confirmPWord.setPreferredSize(new Dimension(200, 30));
        this.getContentPane().add(confirmPanel);

        JPanel panelButtons = new JPanel();
        panelButtons.add(this.applyButton);
        panelButtons.add(this.cancelButton);
        this.getContentPane().add(panelButtons);
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public JButton getApplyButton() {
        return applyButton;
    }

    public JTextField getConfirmPWord() {
        return confirmPWord;
    }

    public JTextField getOldPWord() {
        return oldPWord;
    }

    public JTextField getNewPWord() {
        return newPWord;
    }
}
