import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PasswordControl implements ActionListener {
    private PasswordMenu passwordMenu;
    private Data data;

    public PasswordControl(PasswordMenu passwordMenu, Data data) {
        this.data = data;
        this.passwordMenu = passwordMenu;
        //System.out.println("I made it in the constructor for login control");
        passwordMenu.getCancelButton().addActionListener(this);
        passwordMenu.getApplyButton().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.passwordMenu.getApplyButton()) {
            //System.out.println("I made it in the action listener for the login button");
            changePassword(passwordMenu.getOldPWord().getText(), passwordMenu.getNewPWord().getText(), passwordMenu.getConfirmPWord().getText());
        } else if (e.getSource() == this.passwordMenu.getCancelButton()) {
            //System.out.println("I made it in the action listener for the cancel button");
            Application.getInstance().getPasswordMenu().setVisible(false);
        }

    }

    public void changePassword(String old, String newPWord, String confirmPWord) {
        if (newPWord.equalsIgnoreCase(confirmPWord)) {
            this.data.changePassword(old, newPWord);
        } else {
            JOptionPane.showMessageDialog((Component)null, "The password was not confirmed.");
        }
    }

}
