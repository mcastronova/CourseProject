import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MainCashierMenu extends JFrame {
    private JButton checkOutButton = new JButton("Checkout");
    private JButton manageProfileButton = new JButton("Manage Profile");


    public MainCashierMenu() {
        this.setLayout(new BoxLayout(this.getContentPane(), 3));
        this.setSize(400, 300);
        this.setDefaultCloseOperation(3);

        JLabel title = new JLabel("Mr. Smith's Grocery Store");
        JPanel panelTitle = new JPanel();
        JPanel panelButtons = new JPanel();
        this.checkOutButton.setPreferredSize(new Dimension(120, 40));
        this.manageProfileButton.setPreferredSize(new Dimension(120, 40));
        panelTitle.add(title);
        panelButtons.add(this.checkOutButton);
        panelButtons.add(this.manageProfileButton);
        this.getContentPane().add(panelTitle);
        this.getContentPane().add(panelButtons);

        this.checkOutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getCheckoutMenu().setVisible(true);
            }
        });

        this.manageProfileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProfileMenu().setVisible(true);
            }
        });
    }
}
