import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CheckoutMenu extends JFrame {
    private JButton finishButton = new JButton("Finish and Pay");
    private JButton addProductButton = new JButton("Add Product");
    private DefaultTableModel items = new DefaultTableModel();
    private JTable itemsTable;
    private JLabel totalLabel;

    public CheckoutMenu() {
        this.itemsTable = new JTable(this.items);
        this.totalLabel = new JLabel("Total: ");
        this.setLayout(new BoxLayout(this.getContentPane(), 1));
        JLabel title = new JLabel("Checkout");
        this.getContentPane().add(title);
        this.setSize(400, 300);
        this.items.addColumn("Product ID");
        this.items.addColumn("Name");
        this.items.addColumn("Price");
        this.items.addColumn("Quantity");
        this.items.addColumn("Cost");
        JPanel orderPanel = new JPanel();
        orderPanel.setLayout(new BoxLayout(orderPanel, 3));
        orderPanel.add(this.itemsTable.getTableHeader());
        orderPanel.add(this.itemsTable);
        orderPanel.add(this.totalLabel);
        this.itemsTable.setFillsViewportHeight(true);
        this.getContentPane().add(orderPanel);

        JPanel panelButton = new JPanel();
        panelButton.setPreferredSize(new Dimension(400, 100));
        panelButton.add(finishButton);
        panelButton.add(addProductButton);
        this.getContentPane().add(panelButton);
    }

    public JButton getAddProductButton() {
        return this.addProductButton;
    }

    public JButton getFinishButton() {
        return this.finishButton;
    }

    public JLabel getTotalLabel() {
        return totalLabel;
    }

    public void addRow(Object[] row) {
        this.items.addRow(row);
        this.items.fireTableDataChanged();
    }
}